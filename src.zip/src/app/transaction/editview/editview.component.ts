import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'app-editview',
  templateUrl: './editview.component.html',
  styleUrls: ['./editview.component.css']
})

export class EditviewComponent implements OnInit {

  constructor(private matDialogRef:MatDialogRef<EditComponent>,
          @Inject(MAT_DIALOG_DATA) public data:any){

           }

  ngOnInit() {
  }

  onNoClick(): void{
    this.matDialogRef.close();
  }

}
