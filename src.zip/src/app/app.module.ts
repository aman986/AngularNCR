import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatInputModule} from "@angular/material/input";
import {MatIconModule} from "@angular/material/icon";
import {MatButtonModule} from "@angular/material/button";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import {LoginService} from "./services/login.service";
import {AuthService} from "./services/auth.service";
import {MenuService} from "./services/menu.service";
import { HomeComponent } from './home/home.component';
import {TieredMenuModule} from 'primeng/tieredmenu';
import {MenuItem} from 'primeng/api';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RequestComponent } from './request/request.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';

import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import { EditComponent } from './transaction/edit/edit.component';
import { EditviewComponent } from './transaction/editview/editview.component';
import {MatDialogModule} from '@angular/material/dialog';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    TransactionComponent,
    RequestComponent,
    ChequeComponent,
    AddressComponent,
    EditComponent,
    EditviewComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule

  ],
  providers: [LoginService,AuthService,MenuService],
  entryComponents:[EditComponent, EditviewComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
