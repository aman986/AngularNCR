import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable()
export class LoginService {

  constructor(private httpClient:HttpClient) {
  }

   checkUserExistence(userObj:any):Observable<any>
   {
     return this.httpClient.get("https://daimalerblog2019-cf.cfapps.io/findboauserbyname/"+userObj.userName);
   }




}
